<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'company' => $_POST['company'],
        'exchange' => $_POST['exchange'],
        'sector' => $_POST['sector'],
        'entry' => $_POST['entry'],
        'exit' => $_POST['exit'],
        'time' => $_POST['time']
    ];

    $file = 'data.txt';
    if (file_exists($file)) {
        $currentData = json_decode(file_get_contents($file), true);
        if (!is_array($currentData)) {
            // Debugging output
            echo "Current data is not an array. Current data: " . json_encode($currentData);
            $currentData = [];
        }
    } else {
        $currentData = [];
    }
    $currentData[] = $data;
    file_put_contents($file, json_encode($currentData));

    echo '<div style="display: flex; justify-content: center; align-items: center; height: 100vh; flex-direction: column;">';
    echo '<p>Data saved successfully!</p>';
    echo '<button onclick="window.location.href=\'admin.php\'">Go Back to Form</button>';
    echo '</div>';
}
?>

