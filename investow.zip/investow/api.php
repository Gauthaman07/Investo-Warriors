<?php
header('Content-Type: application/json');

$file = 'data.txt';
if (file_exists($file)) {
    $data = json_decode(file_get_contents($file), true);
    if (is_array($data)) {
        echo json_encode(['data' => $data]);
    } else {
        // Debugging output
        echo json_encode(['error' => 'Data is not an array', 'data' => $data]);
    }
} else {
    echo json_encode(['error' => 'File does not exist']);
}
?>
