<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
</head>
<style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        form {
            background-color: #f2f2f2;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: inline-block;
            width: 150px; /* Adjust this width as needed */
            margin-bottom: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color:#111;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #111;
            border:1px solid white;
        }
    </style>
<body>
<form action="save_data.php" method="POST" onsubmit="return validateForm()">
    <label for="company">Company Name:</label>
    <input type="text" id="company" name="company" required><br><br>

    <label for="exchange">Stock Exchange:</label>
    <input type="text" id="exchange" name="exchange" required><br><br>

    <label for="sector">Sector:</label>
    <input type="text" id="sector" name="sector" required><br><br>

    <label for="entry">Entry Point:</label>
    <input type="text" id="entry" name="entry" required><br><br>

    <label for="exit">Exit Point:</label>
    <input type="text" id="exit" name="exit" required><br><br>

    <label for="time">Time Period:</label>
    <input type="text" id="time" name="time" required><br><br>

    <button type="submit">Save</button>
</form>

</body>
</html>

